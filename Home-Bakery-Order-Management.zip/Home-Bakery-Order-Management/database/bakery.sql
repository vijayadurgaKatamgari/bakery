CREATE DATABASE IF NOT EXISTS bakery_db;
USE bakery_db;

INSERT INTO products (name, category, price, description, image_url, available)
VALUES
('Chocolate Cake','Cakes',550,'Rich chocolate cake with chocolate cream','https://images.unsplash.com/photo-1578985545062-69928b1d9587',true),
('Red Velvet Cake','Cakes',650,'Soft red velvet cake with cream cheese frosting','https://images.unsplash.com/photo-1586788680434-30d324b2d46f',true),
('Cupcake Box','Cupcakes',300,'Box of six assorted cupcakes','https://images.unsplash.com/photo-1587668178277-295251f900ce',true),
('Brownie Box','Brownies',250,'Fudgy chocolate brownies','https://images.unsplash.com/photo-1564355808539-22fda35bed7e',true),
('Cookies Box','Cookies',220,'Freshly baked assorted cookies','https://images.unsplash.com/photo-1499636136210-6f4ee915583e',true);
