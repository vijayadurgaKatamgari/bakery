import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API = 'http://localhost:8080/api';

function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState(null);
  const [order, setOrder] = useState(null);
  const [form, setForm] = useState({
    customerName:'', phone:'', address:'', deliveryDate:'',
    customization:'', quantity:1
  });
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  useEffect(() => {
    axios.get(`${API}/products`)
      .then(r => setProducts(r.data))
      .catch(() => setMessage('Start the Spring Boot backend to load products.'))
      .finally(() => setLoading(false));
  }, []);

  const addToCart = (p) => {
    setCart(p);
    setMessage(`${p.name} added to your order.`);
  };

  const placeOrder = async (e) => {
    e.preventDefault();
    if (!cart) return;
    const totalAmount = cart.price * Number(form.quantity) + 50;
    try {
      const res = await axios.post(`${API}/orders`, {
        ...form, quantity: Number(form.quantity), totalAmount
      });
      setOrder(res.data);
      setMessage('');
    } catch {
      setMessage('Please check the backend and your form details.');
    }
  };

  return (
    <div>
      <header className="hero">
        <nav><h1>🧁 Sweet Home Bakery</h1><span>Freshly baked with love ❤️</span></nav>
        <div className="heroText">
          <h2>Make every celebration sweeter.</h2>
          <p>Order cakes, cupcakes, brownies and cookies with custom designs.</p>
        </div>
      </header>

      <main>
        <section>
          <h2 className="sectionTitle">Our Best Sellers</h2>
          {loading ? <p>Loading products...</p> : (
            <div className="grid">
              {products.map(p => (
                <article className="card" key={p.id}>
                  <img src={p.imageUrl} alt={p.name} />
                  <div className="cardBody">
                    <span className="tag">{p.category}</span>
                    <h3>{p.name}</h3>
                    <p>{p.description}</p>
                    <div className="row">
                      <strong>₹{p.price}</strong>
                      <button onClick={() => addToCart(p)}>Customize & Order</button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>

        {cart && !order && (
          <section className="checkout">
            <h2>🎂 Customize {cart.name}</h2>
            <p className="price">Base price: ₹{cart.price}</p>
            <form onSubmit={placeOrder}>
              <input required placeholder="Customer Name"
                value={form.customerName}
                onChange={e=>setForm({...form,customerName:e.target.value})}/>
              <input required pattern="[0-9]{10}" placeholder="10-digit Phone"
                value={form.phone}
                onChange={e=>setForm({...form,phone:e.target.value})}/>
              <input required placeholder="Delivery Address"
                value={form.address}
                onChange={e=>setForm({...form,address:e.target.value})}/>
              <label>Delivery Date</label>
              <input required type="date"
                value={form.deliveryDate}
                onChange={e=>setForm({...form,deliveryDate:e.target.value})}/>
              <input required min="1" type="number" placeholder="Quantity"
                value={form.quantity}
                onChange={e=>setForm({...form,quantity:e.target.value})}/>
              <textarea placeholder="Customization: name on cake, theme, message, eggless, etc."
                value={form.customization}
                onChange={e=>setForm({...form,customization:e.target.value})}/>
              <div className="summary">
                <span>Product: ₹{cart.price} × {form.quantity}</span>
                <span>Delivery: ₹50</span>
                <strong>Total: ₹{cart.price * Number(form.quantity) + 50}</strong>
              </div>
              <button className="fullBtn" type="submit">🎉 Place Order</button>
            </form>
          </section>
        )}

        {order && (
          <section className="confirmation">
            <div className="success">✓</div>
            <h2>Order Placed Successfully!</h2>
            <p>Order ID: <strong>#{order.id}</strong></p>
            <p>Thank you, {order.customerName}!</p>
            <div className="status">
              <span className="active">✓ Order Placed</span>
              <span>○ Confirmed</span>
              <span>○ Preparing</span>
              <span>○ Ready</span>
              <span>○ Out for Delivery</span>
              <span>○ Delivered</span>
            </div>
            <h3>Total: ₹{order.totalAmount}</h3>
            <button onClick={()=>{setOrder(null);setCart(null);setForm({...form,customerName:'',phone:'',address:'',deliveryDate:'',customization:'',quantity:1})}}>
              Order Another Item
            </button>
          </section>
        )}

        {message && <div className="message">{message}</div>}
      </main>

      <footer>© 2026 Sweet Home Bakery • Home Bakery Order Management System</footer>
    </div>
  );
}

export default App;
