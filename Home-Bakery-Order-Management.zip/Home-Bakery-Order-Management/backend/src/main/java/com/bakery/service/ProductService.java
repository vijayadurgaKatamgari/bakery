package com.bakery.service;

import com.bakery.entity.Product;
import com.bakery.repository.ProductRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProductService {
    private final ProductRepository repository;

    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    public List<Product> getAll() { return repository.findAll(); }
    public Product getById(Long id) { return repository.findById(id).orElseThrow(); }
    public Product save(Product product) { return repository.save(product); }
    public Product update(Long id, Product data) {
        Product p = getById(id);
        p.setName(data.getName());
        p.setCategory(data.getCategory());
        p.setPrice(data.getPrice());
        p.setDescription(data.getDescription());
        p.setImageUrl(data.getImageUrl());
        p.setAvailable(data.isAvailable());
        return repository.save(p);
    }
    public void delete(Long id) { repository.deleteById(id); }
}
