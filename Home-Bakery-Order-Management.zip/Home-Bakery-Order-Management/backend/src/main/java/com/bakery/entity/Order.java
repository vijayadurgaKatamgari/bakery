package com.bakery.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name = "orders")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String customerName;

    @NotBlank
    @Pattern(regexp = "^[0-9]{10}$", message = "Phone must contain 10 digits")
    private String phone;

    @NotBlank
    private String address;

    @NotBlank
    private String deliveryDate;

    private String customization;

    @Min(1)
    private int quantity = 1;

    @Min(0)
    private double totalAmount;

    private String status = "PENDING";
}
